# Less is More: Simple yet Effective Heuristics Community Detection with Graph Convolution Network
